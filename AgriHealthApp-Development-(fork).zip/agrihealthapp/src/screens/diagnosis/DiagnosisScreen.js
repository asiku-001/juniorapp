import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Platform,
  Alert
} from 'react-native';
import {
  Text,
  Card,
  Button,
  Title,
  RadioButton,
  TextInput,
  Chip,
  Divider,
  Portal,
  Dialog,
  List,
  ActivityIndicator
} from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as ImagePicker from 'react-native-image-picker';
import axios from 'axios';
import { API_URL } from '../../config/api';
import { theme } from '../../config/theme';

// Plant and animal types
const plantTypes = [
  'Tomato', 'Potato', 'Corn', 'Rice', 'Wheat',
  'Apple', 'Mango', 'Cucumber', 'Pepper', 'Other'
];

const animalTypes = [
  'Cattle', 'Sheep', 'Goat', 'Poultry', 'Pig',
  'Horse', 'Rabbit', 'Fish', 'Other'
];

// Common symptoms for plants
const plantSymptoms = [
  'Leaf spots', 'Yellowing leaves', 'Wilting', 'Stunted growth',
  'Leaf curl', 'Powdery coating', 'Rotting', 'Mold', 'Black spots',
  'Brown edges', 'Holes in leaves', 'Blisters', 'White spots'
];

// Common symptoms for livestock
const animalSymptoms = [
  'Fever', 'Loss of appetite', 'Lameness', 'Coughing',
  'Diarrhea', 'Weight loss', 'Skin lesions', 'Lethargy',
  'Nasal discharge', 'Difficulty breathing', 'Abnormal behavior'
];

const DiagnosisScreen = ({ navigation }) => {
  const [diagnosisType, setDiagnosisType] = useState('plant');
  const [speciesName, setSpeciesName] = useState('');
  const [customSpecies, setCustomSpecies] = useState('');
  const [symptoms, setSymptoms] = useState([]);
  const [image, setImage] = useState(null);
  const [imageSource, setImageSource] = useState(null);
  const [notes, setNotes] = useState('');
  const [temperature, setTemperature] = useState('');

  const [showSpeciesDialog, setShowSpeciesDialog] = useState(false);
  const [showSymptomsDialog, setShowSymptomsDialog] = useState(false);
  const [loading, setLoading] = useState(false);

  const currentSymptomsList = diagnosisType === 'plant' ? plantSymptoms : animalSymptoms;
  const currentSpeciesList = diagnosisType === 'plant' ? plantTypes : animalTypes;

  // Reset state when diagnosis type changes
  useEffect(() => {
    setSpeciesName('');
    setCustomSpecies('');
    setSymptoms([]);
    setImage(null);
    setImageSource(null);
    setNotes('');
  }, [diagnosisType]);

  const handleSpeciesSelect = (species) => {
    if (species === 'Other') {
      setSpeciesName('Other');
    } else {
      setSpeciesName(species);
      setCustomSpecies('');
    }
    setShowSpeciesDialog(false);
  };

  const toggleSymptom = (symptom) => {
    if (symptoms.includes(symptom)) {
      setSymptoms(symptoms.filter(s => s !== symptom));
    } else {
      setSymptoms([...symptoms, symptom]);
    }
  };

  const takePicture = async () => {
    try {
      navigation.navigate('Camera', {
        onPictureTaken: (photoUri) => {
          setImage({
            uri: photoUri,
            type: 'image/jpeg',
            name: 'photo.jpg',
          });
          setImageSource({ uri: photoUri });
        },
      });
    } catch (error) {
      console.error('Failed to take picture:', error);
      Alert.alert('Error', 'Failed to take picture');
    }
  };

  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibrary({
        mediaType: 'photo',
        quality: 0.8,
      });

      if (!result.didCancel && result.assets && result.assets.length > 0) {
        const selectedImage = result.assets[0];
        setImage({
          uri: selectedImage.uri,
          type: selectedImage.type || 'image/jpeg',
          name: selectedImage.fileName || 'photo.jpg',
        });
        setImageSource({ uri: selectedImage.uri });
      }
    } catch (error) {
      console.error('Failed to pick image:', error);
      Alert.alert('Error', 'Failed to select image');
    }
  };

  const submitDiagnosis = async () => {
    // Validation
    if (!speciesName) {
      Alert.alert('Missing Information', 'Please select a plant or animal type');
      return;
    }

    if (speciesName === 'Other' && !customSpecies) {
      Alert.alert('Missing Information', 'Please enter the species name');
      return;
    }

    if (symptoms.length === 0) {
      Alert.alert('Missing Information', 'Please select at least one symptom');
      return;
    }

    setLoading(true);

    try {
      // Create form data for image upload
      const formData = new FormData();

      // Add diagnosis data
      formData.append('type', diagnosisType);
      formData.append('speciesName', speciesName === 'Other' ? customSpecies : speciesName);
      symptoms.forEach(symptom => {
        formData.append('symptoms[]', symptom);
      });

      if (temperature) {
        formData.append('temperature', parseFloat(temperature));
      }

      if (notes) {
        formData.append('notes', notes);
      }

      // Add image if available
      if (image) {
        formData.append('image', image);
      }

      const response = await axios.post(`${API_URL}/diagnosis`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.data && response.data.diagnosis) {
        navigation.navigate('DiagnosisResult', {
          diagnosis: response.data.diagnosis,
          diseaseDetails: response.data.diseaseDetails || null
        });
      } else {
        throw new Error('Invalid response from server');
      }
    } catch (error) {
      console.error('Diagnosis submission error:', error);
      Alert.alert(
        'Submission Error',
        'Unable to submit diagnosis. Please try again later.',
        [{ text: 'OK' }]
      );
    } finally {
      setLoading(false);
    }
  };

  // For demo purposes, navigate directly to results
  const handleDemoSubmit = () => {
    // In a real app, we would submit to the API

    // For demo, create a sample diagnosis result
    const mockDiagnosis = {
      id: 'demo-id',
      type: diagnosisType,
      speciesName: speciesName === 'Other' ? customSpecies : speciesName,
      symptoms,
      imageUrl: imageSource?.uri || null,
      temperature: temperature ? parseFloat(temperature) : null,
      notes,
      createdAt: new Date().toISOString(),
      diagnosisResult: diagnosisType === 'plant' ? 'Late Blight' : 'Mastitis',
      confidence: 0.85,
      status: 'completed'
    };

    // Mock disease details
    const mockDiseaseDetails = {
      name: diagnosisType === 'plant' ? 'Late Blight' : 'Mastitis',
      description: diagnosisType === 'plant'
        ? 'Late blight is a serious disease of potato and tomato plants caused by the fungus-like organism Phytophthora infestans.'
        : 'Mastitis is an inflammatory reaction of the udder tissue to bacterial, chemical, thermal or mechanical injury.',
      symptoms: diagnosisType === 'plant'
        ? ['Dark brown spots on leaves', 'White fungal growth', 'Brown lesions on stems']
        : ['Swollen udder', 'Pain and discomfort', 'Abnormal milk', 'Reduced milk production'],
      causes: diagnosisType === 'plant'
        ? 'Caused by the pathogen Phytophthora infestans which thrives in cool, wet conditions.'
        : 'Commonly caused by bacterial infections. Poor milking hygiene and injured teats increase risk.',
      preventionMethods: diagnosisType === 'plant'
        ? ['Use resistant varieties', 'Provide good air circulation', 'Avoid overhead irrigation']
        : ['Good milking hygiene', 'Proper milking technique', 'Clean housing'],
      treatmentMethods: diagnosisType === 'plant'
        ? ['Apply fungicides preventatively', 'Remove and destroy infected plants']
        : ['Antibiotics', 'Anti-inflammatory drugs', 'Frequent milking of affected quarters']
    };

    navigation.navigate('DiagnosisResult', {
      diagnosis: mockDiagnosis,
      diseaseDetails: mockDiseaseDetails
    });
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.scrollView}>
        {/* Diagnosis Type */}
        <Title style={styles.sectionTitle}>Select diagnosis type</Title>
        <Card style={styles.card}>
          <Card.Content style={styles.radioButtonsContainer}>
            <TouchableOpacity
              style={[
                styles.typeButton,
                diagnosisType === 'plant' && styles.typeButtonSelected
              ]}
              onPress={() => setDiagnosisType('plant')}
            >
              <MaterialCommunityIcons
                name="leaf"
                size={24}
                color={diagnosisType === 'plant' ? theme.colors.primary : theme.colors.gray}
              />
              <Text
                style={[
                  styles.typeButtonText,
                  diagnosisType === 'plant' && styles.typeButtonTextSelected
                ]}
              >
                Plant
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.typeButton,
                diagnosisType === 'livestock' && styles.typeButtonSelected
              ]}
              onPress={() => setDiagnosisType('livestock')}
            >
              <MaterialCommunityIcons
                name="cow"
                size={24}
                color={diagnosisType === 'livestock' ? theme.colors.primary : theme.colors.gray}
              />
              <Text
                style={[
                  styles.typeButtonText,
                  diagnosisType === 'livestock' && styles.typeButtonTextSelected
                ]}
              >
                Livestock
              </Text>
            </TouchableOpacity>
          </Card.Content>
        </Card>

        {/* Plant/Animal Type */}
        <Title style={styles.sectionTitle}>
          {diagnosisType === 'plant' ? 'Select plant type' : 'Select animal type'}
        </Title>
        <Card style={styles.card}>
          <Card.Content>
            <TouchableOpacity
              style={styles.dropdownButton}
              onPress={() => setShowSpeciesDialog(true)}
            >
              <Text style={styles.dropdownButtonText}>
                {speciesName || `Select ${diagnosisType === 'plant' ? 'plant' : 'animal'} type`}
              </Text>
              <MaterialCommunityIcons name="chevron-down" size={24} color={theme.colors.gray} />
            </TouchableOpacity>

            {speciesName === 'Other' && (
              <TextInput
                mode="outlined"
                label="Enter species name"
                value={customSpecies}
                onChangeText={text => setCustomSpecies(text)}
                style={styles.input}
                theme={{ colors: { primary: theme.colors.primary } }}
              />
            )}
          </Card.Content>
        </Card>

        {/* Symptoms */}
        <Title style={styles.sectionTitle}>Select symptoms</Title>
        <Card style={styles.card}>
          <Card.Content>
            <TouchableOpacity
              style={styles.dropdownButton}
              onPress={() => setShowSymptomsDialog(true)}
            >
              <Text style={styles.dropdownButtonText}>
                {symptoms.length > 0
                  ? `${symptoms.length} symptom${symptoms.length > 1 ? 's' : ''} selected`
                  : 'Select symptoms'
                }
              </Text>
              <MaterialCommunityIcons name="chevron-down" size={24} color={theme.colors.gray} />
            </TouchableOpacity>

            {symptoms.length > 0 && (
              <View style={styles.selectedSymptomsContainer}>
                {symptoms.map(symptom => (
                  <Chip
                    key={symptom}
                    mode="outlined"
                    onClose={() => toggleSymptom(symptom)}
                    style={styles.symptomChip}
                  >
                    {symptom}
                  </Chip>
                ))}
              </View>
            )}
          </Card.Content>
        </Card>

        {/* Image Upload */}
        <Title style={styles.sectionTitle}>Upload image (optional)</Title>
        <Card style={styles.card}>
          <Card.Content style={styles.imageUploadContainer}>
            {imageSource ? (
              <>
                <Image source={imageSource} style={styles.previewImage} />
                <View style={styles.imageButtonsContainer}>
                  <Button
                    mode="contained"
                    onPress={takePicture}
                    style={[styles.imageButton, { marginRight: 10 }]}
                  >
                    Retake
                  </Button>
                  <Button
                    mode="outlined"
                    onPress={() => {
                      setImage(null);
                      setImageSource(null);
                    }}
                    style={styles.imageButton}
                  >
                    Remove
                  </Button>
                </View>
              </>
            ) : (
              <View style={styles.imageButtonsContainer}>
                <Button
                  mode="contained"
                  icon="camera"
                  onPress={takePicture}
                  style={[styles.imageButton, { marginRight: 10 }]}
                >
                  Take Photo
                </Button>
                <Button
                  mode="outlined"
                  icon="image"
                  onPress={pickImage}
                  style={styles.imageButton}
                >
                  Gallery
                </Button>
              </View>
            )}
          </Card.Content>
        </Card>

        {/* Additional Information */}
        <Title style={styles.sectionTitle}>Additional information (optional)</Title>
        <Card style={styles.card}>
          <Card.Content>
            <TextInput
              mode="outlined"
              label="Temperature (°C)"
              value={temperature}
              onChangeText={text => {
                // Allow only numbers and decimal point
                if (/^\d*\.?\d*$/.test(text) || text === '') {
                  setTemperature(text);
                }
              }}
              keyboardType="numeric"
              style={styles.input}
              theme={{ colors: { primary: theme.colors.primary } }}
            />

            <TextInput
              mode="outlined"
              label="Notes"
              value={notes}
              onChangeText={text => setNotes(text)}
              multiline
              numberOfLines={4}
              style={[styles.input, styles.notesInput]}
              theme={{ colors: { primary: theme.colors.primary } }}
            />
          </Card.Content>
        </Card>

        {/* Submit Button */}
        <Button
          mode="contained"
          onPress={handleDemoSubmit} // Use submitDiagnosis in real app
          style={styles.submitButton}
          disabled={loading}
          loading={loading}
        >
          Submit for Diagnosis
        </Button>

        <View style={styles.spacer} />
      </ScrollView>

      {/* Species Selection Dialog */}
      <Portal>
        <Dialog
          visible={showSpeciesDialog}
          onDismiss={() => setShowSpeciesDialog(false)}
          style={styles.dialog}
        >
          <Dialog.Title>
            {diagnosisType === 'plant' ? 'Select Plant Type' : 'Select Animal Type'}
          </Dialog.Title>
          <Dialog.Content>
            <ScrollView style={{ maxHeight: 300 }}>
              {currentSpeciesList.map(species => (
                <List.Item
                  key={species}
                  title={species}
                  onPress={() => handleSpeciesSelect(species)}
                  right={props =>
                    speciesName === species ? (
                      <MaterialCommunityIcons
                        name="check"
                        size={24}
                        color={theme.colors.primary}
                      />
                    ) : null
                  }
                />
              ))}
            </ScrollView>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setShowSpeciesDialog(false)}>Cancel</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      {/* Symptoms Selection Dialog */}
      <Portal>
        <Dialog
          visible={showSymptomsDialog}
          onDismiss={() => setShowSymptomsDialog(false)}
          style={styles.dialog}
        >
          <Dialog.Title>Select Symptoms</Dialog.Title>
          <Dialog.Content>
            <ScrollView style={{ maxHeight: 300 }}>
              {currentSymptomsList.map(symptom => (
                <List.Item
                  key={symptom}
                  title={symptom}
                  onPress={() => toggleSymptom(symptom)}
                  right={props =>
                    symptoms.includes(symptom) ? (
                      <MaterialCommunityIcons
                        name="check"
                        size={24}
                        color={theme.colors.primary}
                      />
                    ) : null
                  }
                />
              ))}
            </ScrollView>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setShowSymptomsDialog(false)}>Done</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  scrollView: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 16,
    marginBottom: 8,
    marginTop: 16,
  },
  card: {
    marginBottom: 8,
    borderRadius: 10,
  },
  radioButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
  },
  typeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surface,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: theme.colors.lightGray,
  },
  typeButtonSelected: {
    borderColor: theme.colors.primary,
    backgroundColor: theme.colors.lightBackground,
  },
  typeButtonText: {
    marginLeft: 8,
    fontSize: 16,
    color: theme.colors.gray,
  },
  typeButtonTextSelected: {
    color: theme.colors.primary,
    fontWeight: 'bold',
  },
  dropdownButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderWidth: 1,
    borderColor: theme.colors.lightGray,
    borderRadius: 5,
  },
  dropdownButtonText: {
    fontSize: 16,
    color: theme.colors.text,
  },
  selectedSymptomsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 10,
  },
  symptomChip: {
    margin: 4,
  },
  input: {
    marginTop: 10,
    backgroundColor: theme.colors.surface,
  },
  notesInput: {
    height: 100,
  },
  imageUploadContainer: {
    alignItems: 'center',
    paddingVertical: 10,
  },
  imageButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
  },
  imageButton: {
    flex: 1,
  },
  previewImage: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    marginBottom: 10,
    resizeMode: 'cover',
  },
  submitButton: {
    marginTop: 20,
    backgroundColor: theme.colors.primary,
    paddingVertical: 8,
  },
  dialog: {
    borderRadius: 10,
  },
  spacer: {
    height: 40,
  },
});

export default DiagnosisScreen;
