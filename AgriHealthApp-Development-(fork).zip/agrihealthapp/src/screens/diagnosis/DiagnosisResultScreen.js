import React, { useState } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Share,
  Platform
} from 'react-native';
import {
  Text,
  Card,
  Button,
  Title,
  Divider,
  List,
  Chip,
  ProgressBar,
  Surface,
  IconButton
} from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';
import { theme } from '../../config/theme';

const DiagnosisResultScreen = ({ navigation, route }) => {
  const { diagnosis, diseaseDetails } = route.params || {};
  const [expandedSection, setExpandedSection] = useState('symptoms');

  if (!diagnosis) {
    return (
      <SafeAreaView style={styles.errorContainer}>
        <MaterialIcons name="error-outline" size={60} color={theme.colors.error} />
        <Text style={styles.errorText}>Diagnosis data not found</Text>
        <Button
          mode="contained"
          onPress={() => navigation.goBack()}
          style={styles.errorButton}
        >
          Go Back
        </Button>
      </SafeAreaView>
    );
  }

  const toggleSection = (section) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const shareResult = async () => {
    try {
      const title = diagnosis.type === 'plant' ?
        `Plant Diagnosis: ${diagnosis.diagnosisResult}` :
        `Livestock Diagnosis: ${diagnosis.diagnosisResult}`;

      const message = `
${title}
Species: ${diagnosis.speciesName}
Confidence: ${Math.round(diagnosis.confidence * 100)}%
Date: ${formatDate(diagnosis.createdAt)}

Symptoms: ${diagnosis.symptoms.join(', ')}

${diseaseDetails?.description || ''}

Treatment: ${diseaseDetails?.treatmentMethods?.join('\n') || 'N/A'}
      `;

      await Share.share({
        title,
        message,
      });
    } catch (error) {
      console.error('Error sharing diagnosis:', error);
    }
  };

  // Calculate confidence level visual representation
  const confidenceLevel = diagnosis.confidence || 0;
  const getConfidenceColor = (level) => {
    if (level < 0.5) return theme.colors.error;
    if (level < 0.75) return theme.colors.warning;
    return theme.colors.success;
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.scrollView}>
        {/* Diagnosis Result Header */}
        <Card style={styles.resultCard}>
          <Card.Content>
            <View style={styles.resultHeaderRow}>
              <View style={styles.resultTypeContainer}>
                <Chip
                  icon={diagnosis.type === 'plant' ? 'leaf' : 'cow'}
                  style={[
                    styles.typeChip,
                    { backgroundColor: diagnosis.type === 'plant' ? theme.colors.lightGreen : theme.colors.lightBlue }
                  ]}
                >
                  {diagnosis.type === 'plant' ? 'Plant' : 'Livestock'}
                </Chip>
                <Text style={styles.dateText}>{formatDate(diagnosis.createdAt)}</Text>
              </View>

              <IconButton
                icon="share-variant"
                size={24}
                onPress={shareResult}
                color={theme.colors.primary}
              />
            </View>

            <Title style={styles.diseaseTitle}>{diagnosis.diagnosisResult}</Title>
            <Text style={styles.speciesText}>{diagnosis.speciesName}</Text>

            <View style={styles.confidenceContainer}>
              <Text style={styles.confidenceLabel}>
                Confidence: {Math.round(confidenceLevel * 100)}%
              </Text>
              <ProgressBar
                progress={confidenceLevel}
                color={getConfidenceColor(confidenceLevel)}
                style={styles.confidenceBar}
              />
            </View>
          </Card.Content>
        </Card>

        {/* Image if available */}
        {diagnosis.imageUrl && (
          <Card style={styles.imageCard}>
            <Card.Content style={styles.imageContainer}>
              <Image
                source={{ uri: diagnosis.imageUrl }}
                style={styles.diagnosisImage}
                resizeMode="cover"
              />
            </Card.Content>
          </Card>
        )}

        {/* Disease Information */}
        {diseaseDetails && (
          <Card style={styles.infoCard}>
            <Card.Content>
              <Text style={styles.description}>{diseaseDetails.description}</Text>

              {/* Symptoms */}
              <List.Accordion
                title="Symptoms"
                left={props => <List.Icon {...props} icon="alert-circle-outline" />}
                expanded={expandedSection === 'symptoms'}
                onPress={() => toggleSection('symptoms')}
                titleStyle={styles.accordionTitle}
                style={styles.accordion}
              >
                <View style={styles.listItemContainer}>
                  {diseaseDetails.symptoms && diseaseDetails.symptoms.map((symptom, index) => (
                    <View key={index} style={styles.listItem}>
                      <MaterialIcons name="check-circle" size={18} color={theme.colors.primary} />
                      <Text style={styles.listItemText}>{symptom}</Text>
                    </View>
                  ))}
                </View>
              </List.Accordion>

              {/* Causes */}
              <List.Accordion
                title="Causes"
                left={props => <List.Icon {...props} icon="help-circle-outline" />}
                expanded={expandedSection === 'causes'}
                onPress={() => toggleSection('causes')}
                titleStyle={styles.accordionTitle}
                style={styles.accordion}
              >
                <Text style={styles.sectionContent}>{diseaseDetails.causes}</Text>
              </List.Accordion>

              {/* Prevention */}
              <List.Accordion
                title="Prevention"
                left={props => <List.Icon {...props} icon="shield-outline" />}
                expanded={expandedSection === 'prevention'}
                onPress={() => toggleSection('prevention')}
                titleStyle={styles.accordionTitle}
                style={styles.accordion}
              >
                <View style={styles.listItemContainer}>
                  {diseaseDetails.preventionMethods && diseaseDetails.preventionMethods.map((method, index) => (
                    <View key={index} style={styles.listItem}>
                      <MaterialIcons name="check-circle" size={18} color={theme.colors.primary} />
                      <Text style={styles.listItemText}>{method}</Text>
                    </View>
                  ))}
                </View>
              </List.Accordion>

              {/* Treatment */}
              <List.Accordion
                title="Treatment"
                left={props => <List.Icon {...props} icon="medical-bag" />}
                expanded={expandedSection === 'treatment'}
                onPress={() => toggleSection('treatment')}
                titleStyle={styles.accordionTitle}
                style={styles.accordion}
              >
                <View style={styles.listItemContainer}>
                  {diseaseDetails.treatmentMethods && diseaseDetails.treatmentMethods.map((method, index) => (
                    <View key={index} style={styles.listItem}>
                      <MaterialIcons name="check-circle" size={18} color={theme.colors.primary} />
                      <Text style={styles.listItemText}>{method}</Text>
                    </View>
                  ))}
                </View>
              </List.Accordion>
            </Card.Content>
          </Card>
        )}

        {/* Notes section if available */}
        {diagnosis.notes && (
          <Card style={styles.notesCard}>
            <Card.Content>
              <Title style={styles.notesTitle}>Notes</Title>
              <Text style={styles.notesText}>{diagnosis.notes}</Text>
            </Card.Content>
          </Card>
        )}

        {/* Temperature Information if available */}
        {diagnosis.temperature && (
          <Card style={styles.temperatureCard}>
            <Card.Content style={styles.temperatureContent}>
              <MaterialCommunityIcons name="thermometer" size={30} color={theme.colors.primary} />
              <View style={styles.temperatureTextContainer}>
                <Text style={styles.temperatureLabel}>Temperature</Text>
                <Text style={styles.temperatureValue}>{diagnosis.temperature}°C</Text>
              </View>
            </Card.Content>
          </Card>
        )}

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <Button
            mode="contained"
            icon="history"
            onPress={() => navigation.navigate('DiagnosisHistory')}
            style={[styles.actionButton, { backgroundColor: theme.colors.darkBlue }]}
          >
            View History
          </Button>
          <Button
            mode="contained"
            icon="camera"
            onPress={() => navigation.navigate('DiagnosisMain')}
            style={styles.actionButton}
          >
            New Diagnosis
          </Button>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  scrollView: {
    padding: 16,
  },
  resultCard: {
    marginBottom: 16,
    borderRadius: 10,
    elevation: 2,
  },
  resultHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  resultTypeContainer: {
    flexDirection: 'column',
  },
  typeChip: {
    marginBottom: 8,
  },
  dateText: {
    fontSize: 12,
    color: theme.colors.gray,
  },
  diseaseTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 8,
    color: theme.colors.primary,
  },
  speciesText: {
    fontSize: 16,
    color: theme.colors.text,
    marginBottom: 16,
  },
  confidenceContainer: {
    marginVertical: 8,
  },
  confidenceLabel: {
    fontSize: 14,
    marginBottom: 5,
  },
  confidenceBar: {
    height: 8,
    borderRadius: 4,
  },
  imageCard: {
    marginBottom: 16,
    borderRadius: 10,
    elevation: 2,
  },
  imageContainer: {
    alignItems: 'center',
    padding: 0,
  },
  diagnosisImage: {
    width: '100%',
    height: 200,
    borderRadius: 8,
  },
  infoCard: {
    marginBottom: 16,
    borderRadius: 10,
    elevation: 2,
  },
  description: {
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 16,
    color: theme.colors.text,
  },
  accordion: {
    backgroundColor: theme.colors.surface,
    paddingLeft: 0,
  },
  accordionTitle: {
    color: theme.colors.text,
    fontSize: 16,
  },
  listItemContainer: {
    paddingLeft: 16,
    paddingRight: 16,
    paddingBottom: 16,
  },
  listItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  listItemText: {
    marginLeft: 10,
    flex: 1,
    fontSize: 14,
    lineHeight: 20,
  },
  sectionContent: {
    paddingHorizontal: 16,
    paddingBottom: 16,
    fontSize: 14,
    lineHeight: 22,
  },
  notesCard: {
    marginBottom: 16,
    borderRadius: 10,
    elevation: 2,
  },
  notesTitle: {
    fontSize: 18,
    marginBottom: 8,
  },
  notesText: {
    fontSize: 14,
    lineHeight: 22,
  },
  temperatureCard: {
    marginBottom: 16,
    borderRadius: 10,
    elevation: 2,
  },
  temperatureContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  temperatureTextContainer: {
    marginLeft: 16,
  },
  temperatureLabel: {
    fontSize: 14,
    color: theme.colors.gray,
  },
  temperatureValue: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  actionButton: {
    flex: 1,
    marginHorizontal: 5,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 18,
    textAlign: 'center',
    marginVertical: 20,
  },
  errorButton: {
    marginTop: 20,
  },
});

export default DiagnosisResultScreen;
