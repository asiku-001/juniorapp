// API Configuration

// For development with Expo - use your local machine's IP address
// export const API_URL = 'http://192.168.1.100:3000/api';

// For development with Expo Go on a real device, use the ngrok URL or your server IP
// export const API_URL = 'https://your-ngrok-url.ngrok.io/api';

// For local development with Expo on emulator/simulator
export const API_URL = 'http://10.0.2.2:3000/api'; // Android emulator
// export const API_URL = 'http://localhost:3000/api'; // iOS simulator

// For production
// export const API_URL = 'https://your-production-server.com/api';

// Weather API - OpenWeatherMap
export const WEATHER_API_KEY = 'your-openweathermap-api-key';
export const WEATHER_API_URL = 'https://api.openweathermap.org/data/2.5';
