const { DataTypes } = require('sequelize');
const sequelize = require('../utils/database');

const PlantDisease = sequelize.define('PlantDisease', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    allowNull: false,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  plantType: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  symptoms: {
    type: DataTypes.ARRAY(DataTypes.STRING),
    allowNull: false
  },
  causes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  preventionMethods: {
    type: DataTypes.ARRAY(DataTypes.TEXT),
    allowNull: true
  },
  treatmentMethods: {
    type: DataTypes.ARRAY(DataTypes.TEXT),
    allowNull: true
  },
  imageUrls: {
    type: DataTypes.ARRAY(DataTypes.STRING),
    allowNull: true
  },
  optimalTemperature: {
    type: DataTypes.STRING,
    allowNull: true
  },
  severity: {
    type: DataTypes.ENUM('low', 'medium', 'high'),
    allowNull: true
  }
});

module.exports = PlantDisease;
