const { DataTypes } = require('sequelize');
const sequelize = require('../utils/database');

const LivestockDisease = sequelize.define('LivestockDisease', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    allowNull: false,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  animalType: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  symptoms: {
    type: DataTypes.ARRAY(DataTypes.STRING),
    allowNull: false
  },
  causes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  preventionMethods: {
    type: DataTypes.ARRAY(DataTypes.TEXT),
    allowNull: true
  },
  treatmentMethods: {
    type: DataTypes.ARRAY(DataTypes.TEXT),
    allowNull: true
  },
  imageUrls: {
    type: DataTypes.ARRAY(DataTypes.STRING),
    allowNull: true
  },
  temperatureFactors: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: 'How temperature affects this disease'
  },
  idealTemperature: {
    type: DataTypes.RANGE(DataTypes.FLOAT),
    allowNull: true,
    comment: 'Range of temperature (in celsius) that is ideal for animals with this disease'
  },
  zoonotic: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: false,
    comment: 'Whether disease can be transmitted to humans'
  },
  severity: {
    type: DataTypes.ENUM('low', 'medium', 'high'),
    allowNull: true
  },
  incubationPeriod: {
    type: DataTypes.STRING,
    allowNull: true
  }
});

module.exports = LivestockDisease;
